export default {
  namespace: 'global',
  state: {},
  reducers: {},
  effects: {},
};
