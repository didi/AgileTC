import Redirect from 'umi/redirect';
export default () => {
  return <Redirect to="/case/caseList/1" />;
};
